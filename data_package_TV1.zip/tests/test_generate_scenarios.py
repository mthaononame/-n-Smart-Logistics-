"""Kiểm thử generate_scenarios.py: `python -m unittest tests.test_generate_scenarios -v`
hoặc `pytest tests/test_generate_scenarios.py` từ thư mục gốc dự án."""
import contextlib
import hashlib
import io
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import generate_scenarios as gs  # noqa: E402

ORIGINALS = ["depots.csv", "vehicles.csv", "orders.csv"]


def quiet(fn, *a, **k):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = fn(*a, **k)
    return rc, out.getvalue(), err.getvalue()


def md5(path):
    return hashlib.md5(Path(path).read_bytes()).hexdigest()


class GeneratorTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)

    def has_base(self):
        return all((ROOT / f).is_file() for f in ORIGINALS)

    def test_deterministic(self):
        a, _, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        b, _, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        self.assertEqual(a, b)

    def test_different_seed_changes_new_orders_only(self):
        a, _, _ = gs.build_all(ROOT, 1, self.tmp)
        b, _, _ = gs.build_all(ROOT, 2, self.tmp)
        self.assertNotEqual(a[self.tmp / "S01" / "orders.csv"], b[self.tmp / "S01" / "orders.csv"])
        self.assertEqual(a[self.tmp / "S01" / "depots.csv"], b[self.tmp / "S01" / "depots.csv"])

    def test_all_scenarios_pass_design_and_have_required_size(self):
        _, info, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        self.assertEqual([i["code"] for i in info], ["S01", "S02", "S03", "S04", "S05"])
        for it in info:
            self.assertEqual(it["fails"], [], it["code"])
            self.assertTrue(20 <= it["m"]["n"] <= 30)
            self.assertEqual(it["m"]["nkho"], 2)
            self.assertTrue(4 <= it["m"]["nveh"] <= 6)

    def test_s05_infeasible_others_feasible(self):
        _, info, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        plan = {i["code"]: i["m"]["plan_full"] for i in info}
        self.assertEqual(plan, {"S01": True, "S02": True, "S03": True, "S04": True, "S05": False})

    def test_first_ten_orders_match_original(self):
        if not self.has_base():
            self.skipTest("không có dữ liệu gốc")
        files, _, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        orig = (ROOT / "orders.csv").read_bytes().decode("utf-8-sig").splitlines()[:11]
        s01 = files[self.tmp / "S01" / "orders.csv"].decode("utf-8-sig").splitlines()[:11]
        self.assertEqual(orig, s01)

    def test_embedded_defaults_equal_original_files(self):
        if not self.has_base():
            self.skipTest("không có dữ liệu gốc")
        empty = self.tmp / "empty"
        empty.mkdir()
        a, _, notes = gs.build_all(empty, gs.DEFAULT_SEED, self.tmp / "o1")
        b, _, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp / "o1")
        self.assertTrue(any("nhúng sẵn" in n for n in notes))
        self.assertEqual(a, b)

    def test_schema_mismatch_stops_with_clear_error(self):
        base = self.tmp / "base"
        base.mkdir()
        # tự dựng 3 file gốc từ bộ nhúng sẵn để test không phụ thuộc file bên ngoài
        (base / "depots.csv").write_bytes(gs.render_csv(gs.SCHEMA["depots"], gs.DEFAULT_DEPOTS))
        veh = [["V01", "K01"] + [gs.DEFAULT_VEHICLE[c] for c in gs.SCHEMA["vehicles"][2:]]]
        (base / "vehicles.csv").write_bytes(gs.render_csv(gs.SCHEMA["vehicles"], veh))
        orders = [list(t) + ["K01;K02"] for t in gs.DEFAULT_ORDERS]
        (base / "orders.csv").write_bytes(gs.render_csv(gs.SCHEMA["orders"], orders))
        gs.load_base(base)                                    # dữ liệu hợp lệ thì đọc được
        p = base / "orders.csv"
        p.write_bytes(p.read_bytes().replace(b"khoi_luong_kg", b"weight_kg"))
        with self.assertRaises(gs.BaseDataError) as cm:
            gs.load_base(base)
        self.assertIn("khác schema", str(cm.exception))
        rc, _, err = quiet(gs.main, ["--base-dir", str(base), "--out-dir", str(self.tmp / "o")])
        self.assertEqual(rc, 2)
        self.assertFalse((self.tmp / "o").exists())          # không ghi gì khi dữ liệu gốc sai

    def test_refuses_out_dir_equal_to_base(self):
        rc, _, err = quiet(gs.main, ["--out-dir", str(ROOT), "--no-validate"])
        self.assertEqual(rc, 2)
        self.assertIn("Từ chối", err)

    def test_never_modifies_original_files(self):
        if not self.has_base():
            self.skipTest("không có dữ liệu gốc")
        before = {f: md5(ROOT / f) for f in ORIGINALS}
        rc, _, _ = quiet(gs.main, ["--out-dir", str(self.tmp / "o")])
        self.assertEqual(rc, 0)
        self.assertEqual(before, {f: md5(ROOT / f) for f in ORIGINALS})

    def test_unknown_scenario_in_only(self):
        rc, _, err = quiet(gs.main, ["--only", "S09", "--out-dir", str(self.tmp / "o")])
        self.assertEqual(rc, 2)

    def test_only_writes_selected_scenario(self):
        rc, _, _ = quiet(gs.main, ["--only", "S03", "--no-validate", "--out-dir", str(self.tmp / "o")])
        self.assertEqual(rc, 0)
        self.assertTrue((self.tmp / "o" / "S03" / "orders.csv").is_file())
        self.assertFalse((self.tmp / "o" / "S01").exists())
        self.assertFalse((self.tmp / "o" / "scenario_description.csv").exists())

    def test_check_detects_manual_edit(self):
        out = self.tmp / "o"
        self.assertEqual(quiet(gs.main, ["--out-dir", str(out)])[0], 0)
        self.assertEqual(quiet(gs.main, ["--check", "--out-dir", str(out)])[0], 0)
        p = out / "S02" / "orders.csv"
        p.write_bytes(p.read_bytes().replace(b"D01", b"D99", 1))
        rc, stdout, _ = quiet(gs.main, ["--check", "--out-dir", str(out)])
        self.assertEqual(rc, 1)
        self.assertIn("S02", stdout)

    def test_design_break_blocks_writing(self):
        out = self.tmp / "o"
        with mock.patch.dict(gs.CONFIG["S05"], {"target_kg": 5000.0}):
            rc, _, err = quiet(gs.main, ["--out-dir", str(out), "--no-validate"])
        self.assertEqual(rc, 1)
        self.assertIn("THIẾT KẾ SAI", err)
        self.assertFalse(out.exists())

    def test_description_has_all_scenarios_and_columns(self):
        files, _, _ = gs.build_all(ROOT, gs.DEFAULT_SEED, self.tmp)
        text = files[self.tmp / "scenario_description.csv"].decode("utf-8-sig")
        lines = text.strip().splitlines()
        self.assertEqual(lines[0].split(",")[0], "ma_kich_ban")
        self.assertEqual(len(lines), 6)
        self.assertIn("so_xe_toi_thieu_uoc_tinh", lines[0])


if __name__ == "__main__":
    unittest.main()
