"""Kiểm thử validate_data.py: chạy bằng `python -m unittest tests.test_validate_data`
hoặc `pytest tests/test_validate_data.py` từ thư mục gốc dự án."""
import csv
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import validate_data as vd  # noqa: E402

DEPOTS = [["ma_kho", "ten_kho", "dia_chi", "vi_do", "kinh_do"],
          ["K01", "Kho 1", "Địa chỉ 1", "10.80", "106.69"],
          ["K02", "Kho 2", "Địa chỉ 2", "10.82", "106.75"]]
VEHICLES = [["ma_xe", "ma_kho_quan_ly", "tai_trong_kg", "the_tich_m3", "gio_bat_dau_ca",
             "gio_ket_thuc_ca", "chi_phi_vnd_km", "chi_phi_co_dinh_vnd"],
            ["V01", "K01", "2500", "15", "06:00", "19:00", "12000", "800000"],
            ["V02", "K02", "2500", "15", "06:00", "19:00", "12000", "800000"]]
ORDERS = [["ma_don", "ten_khach_hang", "dia_chi", "vi_do", "kinh_do", "khoi_luong_kg",
           "the_tich_m3", "thoi_gian_phuc_vu_phut", "gio_bat_dau", "gio_ket_thuc", "kho_phuc_vu"],
          ["D01", "A", "Quận 1", "10.77", "106.70", "300", "1.0", "20", "08:00", "12:00", "K01;K02"],
          ["D02", "B", "Quận 3", "10.78", "106.68", "400", "2.0", "15", "09:00", "14:00", "K01"]]


def write(folder, name, rows):
    with open(Path(folder) / f"{name}.csv", "w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(rows)


class ValidatorTest(unittest.TestCase):
    def run_case(self, depots=DEPOTS, vehicles=VEHICLES, orders=ORDERS):
        with tempfile.TemporaryDirectory() as d:
            write(d, "depots", depots)
            write(d, "vehicles", vehicles)
            write(d, "orders", orders)
            return vd.validate_folder(d, "T")

    def codes(self, issues, level=None):
        return {i.code for i in issues if level is None or i.level == level}

    def with_order(self, idx, col, value):
        rows = [r[:] for r in ORDERS]
        rows[idx][ORDERS[0].index(col)] = value
        return rows

    def test_valid_data_has_no_errors(self):
        self.assertEqual(self.codes(self.run_case(), "ERROR"), set())

    def test_duplicate_order_id(self):
        rows = [r[:] for r in ORDERS]
        rows[2][0] = "D01"
        issues = self.run_case(orders=rows)
        dup = [i for i in issues if i.code == "E_DUP_ID"]
        self.assertEqual(len(dup), 1)
        self.assertEqual(dup[0].line, 3)
        self.assertEqual(dup[0].file, "orders.csv")

    def test_missing_value(self):
        issues = self.run_case(orders=self.with_order(1, "ten_khach_hang", ""))
        self.assertIn("E_EMPTY", self.codes(issues, "ERROR"))

    def test_bad_coordinates(self):
        issues = self.run_case(orders=self.with_order(1, "vi_do", "106.70"))
        self.assertIn("E_COORD_RANGE", self.codes(issues, "ERROR"))
        issues = self.run_case(orders=self.with_order(1, "vi_do", "0"))
        self.assertEqual(self.codes(issues, "ERROR"), set())  # lat 0, lon 106.7 hợp lệ về phạm vi
        self.assertIn("W_COORD_OUTSIDE_HCM", self.codes(issues, "WARNING"))

    def test_decimal_comma(self):
        issues = self.run_case(orders=self.with_order(1, "khoi_luong_kg", "300,5"))
        self.assertIn("E_NOT_NUMBER", self.codes(issues, "ERROR"))

    def test_non_positive_weight_and_volume(self):
        rows = self.with_order(1, "khoi_luong_kg", "-5")
        rows[2][ORDERS[0].index("the_tich_m3")] = "0"
        issues = self.run_case(orders=rows)
        self.assertEqual(sum(1 for i in issues if i.code == "E_NON_POSITIVE"), 2)

    def test_bad_time_format_and_order(self):
        issues = self.run_case(orders=self.with_order(1, "gio_bat_dau", "25:00"))
        self.assertIn("E_TIME_FORMAT", self.codes(issues, "ERROR"))
        issues = self.run_case(orders=self.with_order(1, "gio_ket_thuc", "07:00"))
        self.assertIn("E_TIME_ORDER", self.codes(issues, "ERROR"))

    def test_vehicle_references_unknown_depot(self):
        rows = [r[:] for r in VEHICLES]
        rows[1][1] = "K09"
        issues = self.run_case(vehicles=rows)
        self.assertIn("E_REF_DEPOT", self.codes(issues, "ERROR"))

    def test_order_references_unknown_depot(self):
        issues = self.run_case(orders=self.with_order(1, "kho_phuc_vu", "K01;K05"))
        bad = [i for i in issues if i.code == "E_REF_DEPOT"]
        self.assertEqual(len(bad), 1)
        self.assertEqual(bad[0].line, 2)

    def test_missing_column(self):
        rows = [r[:] for r in ORDERS]
        for r in rows:
            del r[ORDERS[0].index("kho_phuc_vu")]
        issues = self.run_case(orders=rows)
        self.assertIn("E_COLUMN_MISSING", self.codes(issues, "ERROR"))

    def test_infeasible_but_valid_data_is_warning_only(self):
        rows = self.with_order(1, "khoi_luong_kg", "9000")
        issues = self.run_case(orders=rows)
        self.assertEqual(self.codes(issues, "ERROR"), set())
        self.assertIn("W_FEAS_ORDER_TOO_HEAVY", self.codes(issues, "WARNING"))
        self.assertIn("W_FEAS_FLEET_WEIGHT", self.codes(issues, "WARNING"))

    def test_window_shorter_than_service_time(self):
        rows = self.with_order(1, "gio_ket_thuc", "08:10")
        issues = self.run_case(orders=rows)
        self.assertEqual(self.codes(issues, "ERROR"), set())
        self.assertIn("W_WINDOW_TOO_SHORT", self.codes(issues, "WARNING"))

    def test_same_location_is_info_not_error(self):
        rows = [r[:] for r in ORDERS]
        rows.append(["D03", "C", "Quận 1", "10.77", "106.70", "100", "0.5", "10", "08:00", "12:00", "K01;K02"])
        issues = self.run_case(orders=rows)
        self.assertEqual(self.codes(issues, "ERROR"), set())
        self.assertIn("I_SAME_LOCATION", self.codes(issues, "INFO"))

    def test_data_is_never_dropped_silently(self):
        """Dòng lỗi vẫn phải được báo cáo đúng số dòng, không bị bỏ qua."""
        rows = [r[:] for r in ORDERS]
        rows.append(["D03", "C", "Quận 1", "abc", "106.70", "100", "0.5", "10", "08:00", "12:00", "K01"])
        issues = self.run_case(orders=rows)
        self.assertTrue(any(i.code == "E_NOT_NUMBER" and i.line == 4 for i in issues))

    def test_shipped_scenarios_have_no_errors(self):
        for code in ("S01", "S02", "S03", "S04", "S05"):
            folder = ROOT / "data" / "scenarios" / code
            if folder.is_dir():
                issues = vd.validate_folder(folder, code)
                self.assertEqual(self.codes(issues, "ERROR"), set(), code)

    def test_s05_is_valid_but_infeasible(self):
        folder = ROOT / "data" / "scenarios" / "S05"
        if folder.is_dir():
            issues = vd.validate_folder(folder, "S05")
            self.assertIn("W_FEAS_ORDER_TOO_HEAVY", self.codes(issues, "WARNING"))


if __name__ == "__main__":
    unittest.main()
