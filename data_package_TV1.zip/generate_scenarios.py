#!/usr/bin/env python3
"""
generate_scenarios.py - Sinh bộ dữ liệu mở rộng và 5 kịch bản S01-S05.

Chạy:  python generate_scenarios.py
Kết quả: data/scenarios/S01..S05/{depots,vehicles,orders}.csv
         data/scenarios/scenario_description.csv

- Không ghi đè depots/vehicles/orders.csv gốc ở thư mục gốc dự án.
- Dùng seed cố định => chạy lại luôn cho ra cùng dữ liệu (tái lập được).
- Cấu trúc cột GIỮ NGUYÊN như file gốc (xem giai_thich_cot.csv).
- Toạ độ D01-D10 và 2 kho là bản gốc. Toạ độ D11-D28 là toạ độ XẤP XỈ của
  địa điểm công khai, cần TV4 xác minh trên bản đồ trước khi chốt.
- Khối lượng, thể tích, hạn giao, đội xe, chi phí là SỐ LIỆU MÔ PHỎNG.
"""
import csv
import random
from pathlib import Path

SEED = 20261110
OUT = Path(__file__).resolve().parent / "data" / "scenarios"

DEPOT_COLS = ["ma_kho", "ten_kho", "dia_chi", "vi_do", "kinh_do"]
VEHICLE_COLS = ["ma_xe", "ma_kho_quan_ly", "tai_trong_kg", "the_tich_m3",
                "gio_bat_dau_ca", "gio_ket_thuc_ca", "chi_phi_vnd_km",
                "chi_phi_co_dinh_vnd"]
ORDER_COLS = ["ma_don", "ten_khach_hang", "dia_chi", "vi_do", "kinh_do",
              "khoi_luong_kg", "the_tich_m3", "thoi_gian_phuc_vu_phut",
              "gio_bat_dau", "gio_ket_thuc", "kho_phuc_vu"]

# ---------------------------------------------------------------- kho (gốc)
DEPOTS = [
    ["K01", "SPX Express - Bưu cục PN/Cầu Kiệu",
     "53 Cù Lao, Cầu Kiệu, Hồ Chí Minh 72222, Việt Nam",
     10.80013297922369, 106.6893717551218],
    ["K02", "Kho J&T 028H87",
     "RQF5+C29, Thủ Đức, Hồ Chí Minh, Việt Nam",
     10.82450621022111, 106.7561346402375],
]

# ------------------------------------------------- điểm giao: D01-D10 là gốc
# (tên, khu vực, vĩ độ, kinh độ, kg, m3, phút dỡ, bắt đầu, hạn chót)
ORIG = [
    ("Metro An Phú", "TP. Thủ Đức", 10.8022968922523, 106.7430916204482, 545.3, 2.11, 28, "10:00", "16:00"),
    ("Chợ Bến Thành", "Quận 1", 10.7726538062566, 106.6980422534495, 309.4, 0.62, 19, "07:00", "10:00"),
    ("Landmark 81", "Bình Thạnh", 10.7962905866861, 106.7234967912236, 286.6, 0.87, 26, "09:00", "15:00"),
    ("Aeon Tân Phú", "Tân Phú", 10.80183610285794, 106.6174280399574, 411.6, 1.72, 19, "07:00", "12:00"),
    ("Crescent Mall", "Quận 7", 10.72870455819639, 106.7188057118523, 317.9, 1.47, 10, "12:00", "17:00"),
    ("Gigamall", "TP. Thủ Đức", 10.82801225659217, 106.7214496399577, 287.4, 1.08, 23, "10:00", "13:00"),
    ("GO! Gò Vấp", "Gò Vấp", 10.82605016075397, 106.6801035669425, 343.3, 1.46, 22, "12:00", "18:00"),
    ("Bệnh viện Chợ Rẫy", "Quận 5", 10.75801215320188, 106.6595238246136, 349.4, 0.73, 11, "08:00", "12:00"),
    ("Chợ Phú Định", "Quận 8", 10.71998637982251, 106.6231008804339, 580.6, 2.07, 25, "07:00", "13:00"),
    ("Sân bay Tân Sơn Nhất", "Tân Bình", 10.81148209872419, 106.6559831838512, 305.2, 0.88, 11, "09:00", "12:00"),
]

# D11-D28: (tên, khu vực, vĩ độ, kinh độ, kiểu hàng)
#   kiểu hàng: "n" = bình thường, "b" = nhẹ nhưng cồng kềnh (nhiều thể tích)
#   toạ độ XẤP XỈ - chờ TV4 xác minh
NEW = [
    ("Vincom Center Đồng Khởi", "Quận 1", 10.7781, 106.7020, "n"),
    ("Chợ Bình Tây", "Quận 6", 10.7506, 106.6503, "n"),
    ("Đầm Sen", "Quận 11", 10.7633, 106.6361, "n"),
    ("Vạn Hạnh Mall", "Quận 10", 10.7708, 106.6702, "b"),
    ("SC VivoCity", "Quận 7", 10.7298, 106.7058, "n"),
    ("Bệnh viện Nhi Đồng 1", "Quận 10", 10.7686, 106.6773, "n"),
    ("Đại học Bách khoa TP.HCM", "Quận 10", 10.7731, 106.6600, "n"),
    ("Thảo Cầm Viên Sài Gòn", "Quận 1", 10.7876, 106.7053, "n"),
    ("Lotte Mart Quận 7", "Quận 7", 10.7413, 106.7022, "n"),
    ("Etown Cộng Hòa", "Tân Bình", 10.8010, 106.6531, "b"),
    ("Công viên Gia Định", "Phú Nhuận", 10.8105, 106.6775, "n"),
    ("Chợ Thủ Đức", "TP. Thủ Đức", 10.8497, 106.7536, "n"),
    ("Suối Tiên", "TP. Thủ Đức", 10.8654, 106.8026, "b"),
    # D24, D25: CÙNG địa điểm với D03, D02 nhưng là đơn khác (mã đơn riêng)
    ("Landmark 81 - Khu văn phòng", "Bình Thạnh", 10.7962905866861, 106.7234967912236, "n"),
    ("Chợ Bến Thành - Cổng Nam", "Quận 1", 10.7726538062566, 106.6980422534495, "n"),
    ("Co.opmart Nguyễn Đình Chiểu", "Quận 3", 10.7840, 106.6870, "n"),
    ("Dinh Độc Lập", "Quận 1", 10.7770, 106.6955, "n"),
    ("Cảng Cát Lái", "TP. Thủ Đức", 10.7600, 106.7970, "n"),
]


def hm(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def to_min(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def base_pool():
    """Trả về danh sách 28 điểm giao với số liệu cho kịch bản S01 (bình thường)."""
    rng = random.Random(SEED)
    pool = []
    for i, (ten, kv, lat, lon, kg, m3, svc, st, en) in enumerate(ORIG, start=1):
        pool.append(dict(ma=f"D{i:02d}", ten=ten, kv=kv, lat=lat, lon=lon,
                         kg=kg, m3=m3, svc=svc, st=st, en=en, kieu="n"))
    for j, (ten, kv, lat, lon, kieu) in enumerate(NEW, start=11):
        if kieu == "b":                       # nhẹ nhưng cồng kềnh
            kg = round(rng.uniform(70, 130), 1)
            m3 = round(rng.uniform(6.5, 9.5), 2)
        else:
            kg = round(rng.uniform(150, 330), 1)
            m3 = round(kg / 1000 * rng.uniform(2.0, 4.5), 2)
        svc = rng.choice([8, 10, 12, 15, 18, 20, 22, 25])
        st = rng.choice([420, 480, 540, 600, 660, 720, 780])   # 07:00 - 13:00
        length = rng.choice([180, 240, 300, 360])
        en = min(st + length, 18 * 60)
        pool.append(dict(ma=f"D{j:02d}", ten=ten, kv=kv, lat=lat, lon=lon,
                         kg=kg, m3=m3, svc=svc, st=hm(st), en=hm(en), kieu=kieu))
    return pool


def vehicles(n_per_depot):
    rows, k = [], 1
    for depot in ("K01", "K02"):
        for _ in range(n_per_depot):
            rows.append([f"V{k:02d}", depot, 2500, 15, "06:00", "19:00", 12000, 800000])
            k += 1
    return rows


def order_row(o, kho="K01;K02"):
    return [o["ma"], o["ten"], o["kv"], o["lat"], o["lon"], o["kg"], o["m3"],
            o["svc"], o["st"] if isinstance(o["st"], str) else hm(o["st"]),
            o["en"] if isinstance(o["en"], str) else hm(o["en"]), kho]


def write_csv(path, header, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    # UTF-8 có BOM, dấu thập phân là chấm - đúng quy ước trong giai_thich_cot.csv
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def scale(o, f):
    """Nhân khối lượng/thể tích với hệ số f (bỏ qua hàng cồng kềnh)."""
    o = dict(o)
    if o["kieu"] == "n":
        o["kg"] = round(o["kg"] * f, 1)
        o["m3"] = round(o["m3"] * f, 2)
    return o


# ------------------------------------------------------------------ kịch bản
def s01(pool):
    orders = [dict(o) for o in pool[:25]]                       # D01-D25
    return DEPOTS, vehicles(2), [order_row(o) for o in orders]


def s02(pool):
    """Nhu cầu cao: 28 đơn, tổng hàng lớn hơn năng lực 5 xe -> cần dùng đủ 6 xe."""
    target = 13200.0
    base = [dict(o) for o in pool[:28]]
    tot = sum(o["kg"] for o in base if o["kieu"] == "n")
    fixed = sum(o["kg"] for o in base if o["kieu"] != "n")
    f = (target - fixed) / tot
    orders = [scale(o, f) for o in base]
    return DEPOTS, vehicles(3), [order_row(o) for o in orders]


def s03(pool):
    """Hạn giao gấp: khung giờ hẹp, dồn vào 08:30-11:30 -> khó gom chuyến."""
    rng = random.Random(SEED + 3)
    orders = []
    for o in (dict(p) for p in pool[:25]):
        st = rng.choice([510, 540, 570, 600])                   # 08:30-10:00
        length = o["svc"] + rng.choice([40, 45, 50, 60, 70, 75])
        length = (length + 4) // 5 * 5
        o["st"], o["en"] = hm(st), hm(st + length)
        orders.append(o)
    return DEPOTS, vehicles(2), [order_row(o) for o in orders]


def s04(pool):
    """Giới hạn kho: 8 đơn chỉ K01, 8 đơn chỉ K02, còn lại phục vụ được cả hai."""
    only_k01 = {"D04", "D07", "D08", "D09", "D12", "D13", "D14", "D20"}
    only_k02 = {"D01", "D06", "D15", "D18", "D19", "D22", "D23", "D24"}
    rows = []
    for o in (dict(p) for p in pool[:24]):
        kho = "K01" if o["ma"] in only_k01 else "K02" if o["ma"] in only_k02 else "K01;K02"
        rows.append(order_row(o, kho))
    return DEPOTS, vehicles(2), rows


def s05(pool):
    """Thiếu năng lực: tổng hàng > tải đội 4 xe, có 1 đơn nặng hơn mọi xe,
    nhiều đơn cồng kềnh -> không thể phân hết đơn, thuật toán phải cảnh báo."""
    target = 11200.0
    base = [dict(o) for o in pool[:26]]
    tot = sum(o["kg"] for o in base if o["kieu"] == "n")
    fixed = sum(o["kg"] for o in base if o["kieu"] != "n")
    f = (target - fixed) / tot
    orders = [scale(o, f) for o in base]
    # D26: đơn nặng hơn tải trọng của bất kỳ xe nào (2500 kg) -> chắc chắn không giao được
    orders[25]["kg"] = 2900.0
    orders[25]["m3"] = 9.8
    # thêm vài đơn cồng kềnh để cả giới hạn thể tích cũng căng
    for ma, kg, m3 in (("D05", 140.0, 8.6), ("D10", 110.0, 9.2), ("D17", 95.0, 8.9)):
        for o in orders:
            if o["ma"] == ma:
                o["kg"], o["m3"], o["kieu"] = kg, m3, "b"
    return DEPOTS, vehicles(2), [order_row(o) for o in orders]


SCENARIOS = [
    ("S01", s01, "Bình thường",
     "Dữ liệu cơ sở mở rộng: đơn phân bố tương đối đều, hạn giao hợp lý, đội xe đủ sức chứa.",
     "25 đơn (D01-D10 giữ nguyên bản gốc); có 2 cặp đơn cùng địa điểm (D03/D24, D02/D25); "
     "có 3 đơn nhẹ nhưng cồng kềnh (D14, D20, D23); mọi đơn phục vụ được từ K01 và K02.",
     "Phân được toàn bộ 25 đơn, không trễ hạn; dùng khoảng 2-4 xe.",
     "Không lỗi; không cảnh báo khả thi."),
    ("S02", s02, "Nhu cầu cao",
     "Nhiều hàng, buộc phải cân nhắc dùng thêm xe để chở hết.",
     "28 đơn, tổng khối lượng lớn hơn năng lực 5 xe; có 6 xe (3 xe/kho); đơn cồng kềnh giữ nguyên.",
     "Phân được toàn bộ 28 đơn; cần dùng đủ 6 xe; chi phí cố định tăng so với S01.",
     "Không lỗi; không cảnh báo khả thi."),
    ("S03", s03, "Hạn giao gấp",
     "Nhiều đơn có khung giờ gần nhau, khó gom chuyến.",
     "25 đơn; khung giờ hẹp (chỉ rộng hơn thời gian dỡ khoảng 40-75 phút), dồn vào 08:30-11:30; 4 xe.",
     "Cần nhiều xe chạy song song hơn S01; chi phí cao hơn S01; có thể trễ hạn một vài đơn tuỳ thuật toán.",
     "Không lỗi; không cảnh báo khả thi (mỗi đơn riêng lẻ vẫn kịp nếu xuất phát sớm)."),
    ("S04", s04, "Giới hạn kho",
     "Một số đơn chỉ được phục vụ từ K01 hoặc K02.",
     "24 đơn: 8 đơn chỉ K01 (cột kho_phuc_vu = K01), 8 đơn chỉ K02, 8 đơn cả hai (K01;K02); 4 xe.",
     "Mọi đơn chỉ-K01 do xe kho K01 giao, mọi đơn chỉ-K02 do xe kho K02 giao; không đơn nào bị gán sai kho.",
     "Không lỗi; không cảnh báo khả thi."),
    ("S05", s05, "Thiếu năng lực vận chuyển",
     "Dữ liệu HỢP LỆ nhưng không có phương án giao đủ hàng, để kiểm tra cơ chế cảnh báo.",
     "26 đơn; tổng khối lượng vượt tải đội 4 xe (10000 kg); D26 nặng 2900 kg hơn tải mọi xe; "
     "có thêm đơn cồng kềnh làm căng giới hạn thể tích.",
     "Không thể phân hết đơn: thuật toán/giao diện phải báo danh sách đơn chưa được phục vụ "
     "(chắc chắn có D26), không được báo lỗi dữ liệu.",
     "Không lỗi (ERROR = 0); có cảnh báo W_FEAS_* (đơn quá tải, tổng tải vượt đội xe)."),
]


def main():
    pool = base_pool()
    desc_rows = []
    for code, fn, ten, mucdich, dacdiem, kq, vld in SCENARIOS:
        depots, vehs, orders = fn(pool)
        d = OUT / code
        write_csv(d / "depots.csv", DEPOT_COLS, depots)
        write_csv(d / "vehicles.csv", VEHICLE_COLS, vehs)
        write_csv(d / "orders.csv", ORDER_COLS, orders)
        tong_kg = round(sum(r[5] for r in orders), 1)
        tong_m3 = round(sum(r[6] for r in orders), 2)
        cap_kg = sum(v[2] for v in vehs)
        cap_m3 = sum(v[3] for v in vehs)
        desc_rows.append([code, ten, mucdich, dacdiem, len(orders), len(depots), len(vehs),
                          tong_kg, cap_kg, tong_m3, cap_m3,
                          f"data/scenarios/{code}", kq, vld])
        print(f"{code}: {len(orders)} đơn, {len(vehs)} xe, {tong_kg} kg / {cap_kg} kg, "
              f"{tong_m3} m3 / {cap_m3} m3")
    write_csv(OUT / "scenario_description.csv",
              ["ma_kich_ban", "ten_kich_ban", "muc_dich", "dac_diem_du_lieu", "so_don",
               "so_kho", "so_xe", "tong_khoi_luong_don_kg", "tong_tai_trong_doi_xe_kg",
               "tong_the_tich_don_m3", "tong_the_tich_doi_xe_m3", "thu_muc",
               "ket_qua_mong_doi", "ket_qua_validator_mong_doi"], desc_rows)


if __name__ == "__main__":
    main()
